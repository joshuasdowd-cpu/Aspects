const API_BASE = "http://localhost:3001";

const $ = (id) => document.getElementById(id);

function fmtDeg(x) {
  const deg = Math.floor(x);
  const min = Math.floor((x - deg) * 60);
  return `${deg}°${String(min).padStart(2,"0")}'`;
}

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, (c) => ({
    "&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#039;"
  }[c]));
}

$("chartForm").addEventListener("submit", async (e) => {
  e.preventDefault();

  const date = $("date").value;
  const time = $("time").value;
  const orbDeg = Number($("orb").value);

  if (!date || !time) return;

  // Offset depends on date (DST), so compute it for that local datetime.
  const dtLocal = new Date(`${date}T${time}:00`);
  const tzOffsetMinutes = dtLocal.getTimezoneOffset(); // minutes to add to local time -> UTC

  $("planets").innerHTML = "Computing…";
  $("aspects").innerHTML = "";

  const resp = await fetch(`${API_BASE}/api/chart`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ date, time, tzOffsetMinutes, orbDeg })
  });

  const data = await resp.json();
  if (!resp.ok) {
    $("planets").innerHTML = `<p>Error: ${escapeHtml(data.error || "Unknown error")}</p>`;
    return;
  }

  const pRows = data.planets.map(p => `
    <tr>
      <td>${escapeHtml(p.key)}</td>
      <td>${escapeHtml(p.sign)} ${fmtDeg(p.degInSign)}</td>
      <td><code>${p.longitude.toFixed(4)}°</code></td>
    </tr>
  `).join("");

  $("planets").innerHTML = `
    <table>
      <thead><tr><th>Body</th><th>Position</th><th>Longitude</th></tr></thead>
      <tbody>${pRows}</tbody>
    </table>
  `;

  const aRows = data.aspects.map(a => `
    <tr>
      <td>${escapeHtml(a.p1)} – ${escapeHtml(a.p2)}</td>
      <td>${escapeHtml(a.type)}</td>
      <td>${a.orb.toFixed(2)}°</td>
    </tr>
  `).join("");

  $("aspects").innerHTML = data.aspects.length
    ? `<table>
         <thead><tr><th>Pair</th><th>Aspect</th><th>Orb</th></tr></thead>
         <tbody>${aRows}</tbody>
       </table>`
    : `<p>No major aspects within the current orb.</p>`;
});
