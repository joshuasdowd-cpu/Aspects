# Aspects Starter (Astrology for Skeptics)

This is a minimal "Aspects" MVP:
- **server/**: Node + Swiss Ephemeris (swisseph-v2) API that returns planet longitudes + major aspects
- **web/**: static website that calls the API and shows the results

## Run the API
```bash
cd server
npm install
npm start
```

API runs on http://localhost:3001

## Run the website
Open `web/index.html` in a browser (or serve it with any static server).

## Deploy flow (Wix friendly)
- Deploy **server/** to Render/Fly/Railway/etc
- Change `API_BASE` in `web/app.js` to your deployed URL
- Host the **web/** files anywhere (Wix pages can call the API too)
