/*
  Aspects Starter API (Node + Swiss Ephemeris)

  POST /api/chart
  Body:
    {
      "date": "YYYY-MM-DD",
      "time": "HH:MM",
      "tzOffsetMinutes": number,   // from JS Date.getTimezoneOffset()
      "orbDeg": 6                  // optional, default 6
    }

  Returns:
    - planet longitudes (0..360) + sign + degree
    - major aspects (0/60/90/120/180) within orb

  Notes:
    - This calculates only ecliptic longitudes (no houses/ASC/MC).
    - It's perfect for the "math receipts" + aspects MVP.
*/
const express = require("express");
const cors = require("cors");
const swe = require("swisseph-v2");

const app = express();
app.use(cors());
app.use(express.json({ limit: "1mb" }));

const SIGNS = [
  "Aries","Taurus","Gemini","Cancer","Leo","Virgo",
  "Libra","Scorpio","Sagittarius","Capricorn","Aquarius","Pisces"
];

// Major bodies for MVP
const PLANETS = [
  { key: "Sun", id: swe.SE_SUN },
  { key: "Moon", id: swe.SE_MOON },
  { key: "Mercury", id: swe.SE_MERCURY },
  { key: "Venus", id: swe.SE_VENUS },
  { key: "Mars", id: swe.SE_MARS },
  { key: "Jupiter", id: swe.SE_JUPITER },
  { key: "Saturn", id: swe.SE_SATURN },
  { key: "Uranus", id: swe.SE_URANUS },
  { key: "Neptune", id: swe.SE_NEPTUNE },
  { key: "Pluto", id: swe.SE_PLUTO }
];

// Wrap callback API -> Promise
function sweJulday(y, m, d, hour) {
  return new Promise((resolve) => {
    swe.swe_julday(y, m, d, hour, swe.SE_GREG_CAL, (jd) => resolve(jd));
  });
}

function sweCalcUt(jd_ut, ipl, flags) {
  return new Promise((resolve, reject) => {
    swe.swe_calc_ut(jd_ut, ipl, flags, (result) => {
      if (result && result.error) return reject(new Error(result.error));
      resolve(result);
    });
  });
}

function norm360(x) {
  let v = x % 360;
  if (v < 0) v += 360;
  return v;
}

function smallestAngle(a, b) {
  let d = Math.abs(norm360(a) - norm360(b));
  if (d > 180) d = 360 - d;
  return d;
}

function signAndDegree(lon) {
  const L = norm360(lon);
  const signIndex = Math.floor(L / 30);
  const degInSign = L - signIndex * 30;
  return { sign: SIGNS[signIndex], degInSign };
}

function computeAspects(planetRows, orbDeg) {
  const ASPECTS = [
    { type: "Conjunction", angle: 0 },
    { type: "Sextile", angle: 60 },
    { type: "Square", angle: 90 },
    { type: "Trine", angle: 120 },
    { type: "Opposition", angle: 180 }
  ];

  const out = [];
  for (let i = 0; i < planetRows.length; i++) {
    for (let j = i + 1; j < planetRows.length; j++) {
      const p1 = planetRows[i];
      const p2 = planetRows[j];
      const d = smallestAngle(p1.longitude, p2.longitude);

      let best = null;
      for (const a of ASPECTS) {
        const orb = Math.abs(d - a.angle);
        if (orb <= orbDeg && (!best || orb < best.orb)) best = { ...a, orb };
      }
      if (best) {
        out.push({
          p1: p1.key,
          p2: p2.key,
          type: best.type,
          exactAngle: best.angle,
          actualAngle: d,
          orb: best.orb
        });
      }
    }
  }
  out.sort((a, b) => a.orb - b.orb);
  return out;
}

app.post("/api/chart", async (req, res) => {
  try {
    const { date, time, tzOffsetMinutes, orbDeg } = req.body || {};
    const orb = typeof orbDeg === "number" ? orbDeg : 6;

    if (!date || !time || typeof tzOffsetMinutes !== "number") {
      return res.status(400).json({ error: "Missing date/time/tzOffsetMinutes" });
    }

    const [Y, M, D] = date.split("-").map(Number);
    const [hh, mm] = time.split(":").map(Number);

    // Local -> UTC using offset minutes from browser (Date.getTimezoneOffset())
    const naiveUtcMs = Date.UTC(Y, M - 1, D, hh, mm, 0);
    const realUtcMs = naiveUtcMs + tzOffsetMinutes * 60_000;
    const utc = new Date(realUtcMs);

    const utcYear = utc.getUTCFullYear();
    const utcMonth = utc.getUTCMonth() + 1;
    const utcDay = utc.getUTCDate();
    const utcHourDecimal = utc.getUTCHours() + utc.getUTCMinutes() / 60 + utc.getUTCSeconds() / 3600;

    const jd_ut = await sweJulday(utcYear, utcMonth, utcDay, utcHourDecimal);

    const flags = swe.SEFLG_SWIEPH | swe.SEFLG_SPEED;

    const planets = [];
    for (const p of PLANETS) {
      const r = await sweCalcUt(jd_ut, p.id, flags);

      // swisseph-v2 returns `longitude` (degrees)
      const lon = typeof r.longitude === "number"
        ? r.longitude
        : (Array.isArray(r.position) ? r.position[0] : NaN);

      const longitude = norm360(lon);
      const { sign, degInSign } = signAndDegree(longitude);

      planets.push({
        key: p.key,
        longitude,
        sign,
        degInSign
      });
    }

    const aspects = computeAspects(planets, orb);

    res.json({
      input: { date, time, tzOffsetMinutes, orbDeg: orb },
      jd_ut,
      planets,
      aspects
    });
  } catch (e) {
    res.status(500).json({ error: String(e?.message || e) });
  }
});

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => console.log(`Aspects API listening on http://localhost:${PORT}`));
